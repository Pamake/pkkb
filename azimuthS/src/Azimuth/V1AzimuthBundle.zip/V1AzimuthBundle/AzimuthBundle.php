<?php

namespace Azimuth\V1AzimuthBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AzimuthBundle extends Bundle
{
}
