<?php

namespace Azimuth\V1AzimuthBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class CarrieresController extends Controller
{

    public function carriereAction()
    {
        return $this->render('AzimuthBundle:Default:Carrieres/layout/carriere.html.twig');
    }
}
